class CommonProto {
    //PROTO_JSON
    static eUserLostConnectRes: number = 10000; //用户断开,网关服务发给其他服
}

export default CommonProto;