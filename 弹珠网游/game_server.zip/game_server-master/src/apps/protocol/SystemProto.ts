export let protoName: string = "SystemProto"

export enum Cmd {
	INVALED = 0,
	
}

export let CmdName:any = {
	[0] : "INVALED",
}