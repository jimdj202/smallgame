import Log2 from '../utils/Log';

let table = {
	["a"]: 111,
	["b"]: 0.52,
	["n"]: false,
	["hhh"]: "eee",
}

Log2.info("hccccc info" , 111111,222222,[1,2,3,4])
Log2.warn("hccccc warn",table)
Log2.error("hccccc error")
console.log("cccccccccccccccccccccc")