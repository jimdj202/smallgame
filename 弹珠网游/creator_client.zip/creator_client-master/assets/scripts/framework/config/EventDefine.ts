export default class EventDefine {
    static EVENT_NET_CONNECTED  = "event_net_connected";
    static EVENT_NET_ERROR      = "event_net_error"
    static EVENT_NET_CLOSED     = "event_net_closed"

}