export let protoName: string = "SystemProto"

export enum Cmd {
	INVALED = 0,
	
}

export let CmdName = {
	[0] : "INVALED",
}