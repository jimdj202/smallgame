cc.Class({
  extends: cc.Component,
  properties: {
    red: {
      type: cc.Sprite,
      default: null,
    },
    green: {
      type: cc.Sprite,
      default: null,
    },
    lawn: {
      type: cc.Sprite,
      default: null,
    },
    soldierDroppable: {
      type: cc.Sprite,
      default: null,
    },
  }
});
