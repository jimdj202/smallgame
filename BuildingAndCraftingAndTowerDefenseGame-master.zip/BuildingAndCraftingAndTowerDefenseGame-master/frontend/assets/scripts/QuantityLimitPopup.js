cc.Class({
    extends: cc.Component,
    //用于window.show/hideQuantityLimitPopup。
    properties: {
      currentLimit: {
        type: cc.Label,
        default: null,
      }, 
    },


    onLoad () {
    },

    start () {

    },
});
