cc.Class({
  extends: cc.Component,  
});
