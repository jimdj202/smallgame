const IngredientCell = require('./IngredientCell');
cc.Class({
  extends: IngredientCell,
  properties: {
    tabNode: cc.Node,
  },
})
