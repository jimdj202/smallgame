<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.2" name="Tile_W256_H128_S02" tilewidth="256" tileheight="128" tilecount="20" columns="5">
 <grid orientation="isometric" width="256" height="128"/>
 <image source="Tile_W256_H128_S02.png" width="1280" height="512"/>
 <terraintypes>
  <terrain name="grass" tile="1"/>
  <terrain name="dirt" tile="2"/>
 </terraintypes>
 <tile id="1" terrain="0,0,0,0"/>
 <tile id="2" terrain="1,1,1,1"/>
 <tile id="3" terrain="0,1,1,1"/>
 <tile id="4" terrain="1,1,0,1"/>
 <tile id="5" terrain="1,1,1,0"/>
 <tile id="6" terrain="1,0,1,1"/>
 <tile id="7" terrain="1,0,1,0"/>
 <tile id="8" terrain="0,0,1,1"/>
 <tile id="9" terrain="0,1,0,1"/>
 <tile id="11" terrain="1,1,0,0"/>
 <tile id="12" terrain="1,0,0,0"/>
 <tile id="13" terrain="0,0,1,0"/>
 <tile id="14" terrain="0,0,0,1"/>
 <tile id="15" terrain="0,1,0,0"/>
</tileset>
