<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.2" name="Tile_W256_H256_S01" tilewidth="256" tileheight="256" tilecount="6" columns="6">
 <image source="Tile_W256_H256_S01.png" width="1548" height="258"/>
</tileset>
