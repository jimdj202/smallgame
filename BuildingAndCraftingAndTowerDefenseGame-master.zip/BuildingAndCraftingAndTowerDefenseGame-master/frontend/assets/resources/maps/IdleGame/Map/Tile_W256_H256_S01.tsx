<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.2" name="Tile_W256_H256_S01" tilewidth="256" tileheight="256" tilecount="6" columns="6">
 <image source="Tile_W256_H256_S01.png" width="1548" height="258"/>
 <tile id="0">
  <properties>
   <property name="boundary_type" value="barrier"/>
  </properties>
  <objectgroup draworder="index">
   <object id="2" x="111" y="100">
    <properties>
     <property name="boundary_type" value="barrier"/>
    </properties>
    <polyline points="0,0 -29,22 -20,49 21,64 63,41 25,-3"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="1">
  <objectgroup draworder="index">
   <object id="1" x="126" y="2">
    <properties>
     <property name="boundary_type" value="barrier"/>
    </properties>
    <polyline points="0,0 -77,29 -96,95 -73,157 -47,216 74,218 108,69 55,1"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="2">
  <objectgroup draworder="index">
   <object id="1" x="127" y="4">
    <properties>
     <property name="boundary_type" value="barrier"/>
    </properties>
    <polyline points="0,0 -64,17 -89,83 -49,228 -2,252 58,243 93,74 73,8 30,-4"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="3">
  <objectgroup draworder="index">
   <object id="2" x="129" y="3">
    <properties>
     <property name="boundary_type" value="barrier"/>
    </properties>
    <polyline points="0,0 -59,3 -109,101 -51,241 20,251 73,222 103,33 62,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="4">
  <objectgroup draworder="index">
   <object id="1" x="108" y="35">
    <properties>
     <property name="boundary_type" value="barrier"/>
    </properties>
    <polyline points="0,0 -28,49 -19,148 10,182 70,178 89,82 57,0 28,-9"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="5">
  <objectgroup draworder="index">
   <object id="2" x="61" y="72">
    <properties>
     <property name="boundary_type" value="barrier"/>
    </properties>
    <polyline points="0,0 6,88 156,91 154,1"/>
   </object>
  </objectgroup>
 </tile>
</tileset>
