<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="Tile_W256_H128_S01" tilewidth="256" tileheight="128" tilecount="10" columns="5">
 <image source="Tile_W256_H128_S01.png" width="1280" height="256"/>
</tileset>
