package storage

func Init() {
	initMySQL()
	initRedis()
}
