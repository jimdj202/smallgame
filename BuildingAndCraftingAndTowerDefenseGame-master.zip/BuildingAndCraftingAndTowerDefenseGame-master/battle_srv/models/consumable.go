package models

type Consumable struct {
	KnapsackId int32 `json:"knapsackId"`
	Count      int32 `json:"count"`
}
