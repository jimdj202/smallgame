package models

type IngredientWithCount struct {
	Ingredient
	Count int32
}
