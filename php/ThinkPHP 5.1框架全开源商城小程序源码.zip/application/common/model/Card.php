<?php
namespace app\common\model;
/**
 * 会员卡管理
 * Class Cart
 * @package app\api\model
 */
class Card extends BaseModel
{
}