<?php
namespace app\common\model;

/**
 * 系统设置模型
 * Class Setting
 * @package app\common\model
 */
class Game extends BaseModel
{
    protected $name = 'game';
	protected $pk = 'id';
 
}