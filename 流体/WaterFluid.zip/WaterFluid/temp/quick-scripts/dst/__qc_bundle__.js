
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/__qc_index__.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}
require('./assets/Script/HelloWorld');
require('./assets/Script/Water');

                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/HelloWorld.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '280c3rsZJJKnZ9RqbALVwtK', 'HelloWorld');
// Script/HelloWorld.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    label: {
      "default": null,
      type: cc.Label
    },
    // defaults, set visually when attaching this script to the Canvas
    text: 'Hello, World!'
  },
  // use this for initialization
  onLoad: function onLoad() {
    this.label.string = this.text;
  },
  // called every frame
  update: function update(dt) {}
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxIZWxsb1dvcmxkLmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwibGFiZWwiLCJ0eXBlIiwiTGFiZWwiLCJ0ZXh0Iiwib25Mb2FkIiwic3RyaW5nIiwidXBkYXRlIiwiZHQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNSQyxJQUFBQSxLQUFLLEVBQUU7QUFDSCxpQkFBUyxJQUROO0FBRUhDLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTTtBQUZOLEtBREM7QUFLUjtBQUNBQyxJQUFBQSxJQUFJLEVBQUU7QUFORSxHQUhQO0FBWUw7QUFDQUMsRUFBQUEsTUFBTSxFQUFFLGtCQUFZO0FBQ2hCLFNBQUtKLEtBQUwsQ0FBV0ssTUFBWCxHQUFvQixLQUFLRixJQUF6QjtBQUNILEdBZkk7QUFpQkw7QUFDQUcsRUFBQUEsTUFBTSxFQUFFLGdCQUFVQyxFQUFWLEVBQWMsQ0FFckI7QUFwQkksQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICBsYWJlbDoge1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5MYWJlbFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgLy8gZGVmYXVsdHMsIHNldCB2aXN1YWxseSB3aGVuIGF0dGFjaGluZyB0aGlzIHNjcmlwdCB0byB0aGUgQ2FudmFzXHJcbiAgICAgICAgdGV4dDogJ0hlbGxvLCBXb3JsZCEnXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIHVzZSB0aGlzIGZvciBpbml0aWFsaXphdGlvblxyXG4gICAgb25Mb2FkOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgdGhpcy5sYWJlbC5zdHJpbmcgPSB0aGlzLnRleHQ7XHJcbiAgICB9LFxyXG5cclxuICAgIC8vIGNhbGxlZCBldmVyeSBmcmFtZVxyXG4gICAgdXBkYXRlOiBmdW5jdGlvbiAoZHQpIHtcclxuXHJcbiAgICB9LFxyXG59KTtcclxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/MyPhysicsManager.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'b77b7Rx6+FDlLve9P/euI/v', 'MyPhysicsManager');
// Script/MyPhysicsManager.js

"use strict";

cc.PhysicsManager.prototype.start = function () {
  if (CC_EDITOR) return;

  if (!this._world) {
    var world = new b2.World(new b2.Vec2(0, -9.5));
    world.SetAllowSleeping(true);
    this._world = world; //liquid 粒子

    var psd = new b2.ParticleSystemDef();
    psd.radius = 0.3;
    psd.dampingStrength = 1.5;
    psd.viscousStrength = 0;
    /*
    if(GlobalData.GameInfoConfig.gameType == 1){
    	psd.dampingStrength = 1.5;
    	psd.viscousStrength = 0;
    }else{
    	psd.dampingStrength = 2;
    	psd.viscousStrength = 0;
    	//psd.elasticStrength = 2;
    	//psd.powderStrength = 1;
    	//psd.gravityScale = 1.5;
    }
    */

    this._particles = this._world.CreateParticleSystem(psd);

    this._initCallback();
  }

  this._enabled = true;
};

b2.Draw.prototype.DrawParticles = function (positionBuffer, radius, colorBuffer, particleCount) {
  //return;
  var color = new cc.Color(255, 255, 255);

  for (var i = 0; i < particleCount; i++) {
    var vec2 = positionBuffer[i];
    this.DrawSolidCircle(vec2, radius * 1.2, 0, color);
  }
};

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxNeVBoeXNpY3NNYW5hZ2VyLmpzIl0sIm5hbWVzIjpbImNjIiwiUGh5c2ljc01hbmFnZXIiLCJwcm90b3R5cGUiLCJzdGFydCIsIkNDX0VESVRPUiIsIl93b3JsZCIsIndvcmxkIiwiYjIiLCJXb3JsZCIsIlZlYzIiLCJTZXRBbGxvd1NsZWVwaW5nIiwicHNkIiwiUGFydGljbGVTeXN0ZW1EZWYiLCJyYWRpdXMiLCJkYW1waW5nU3RyZW5ndGgiLCJ2aXNjb3VzU3RyZW5ndGgiLCJfcGFydGljbGVzIiwiQ3JlYXRlUGFydGljbGVTeXN0ZW0iLCJfaW5pdENhbGxiYWNrIiwiX2VuYWJsZWQiLCJEcmF3IiwiRHJhd1BhcnRpY2xlcyIsInBvc2l0aW9uQnVmZmVyIiwiY29sb3JCdWZmZXIiLCJwYXJ0aWNsZUNvdW50IiwiY29sb3IiLCJDb2xvciIsImkiLCJ2ZWMyIiwiRHJhd1NvbGlkQ2lyY2xlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBQSxFQUFFLENBQUNDLGNBQUgsQ0FBa0JDLFNBQWxCLENBQTRCQyxLQUE1QixHQUFvQyxZQUFVO0FBQzdDLE1BQUlDLFNBQUosRUFBZTs7QUFDZixNQUFJLENBQUMsS0FBS0MsTUFBVixFQUFrQjtBQUNqQixRQUFJQyxLQUFLLEdBQUcsSUFBSUMsRUFBRSxDQUFDQyxLQUFQLENBQWMsSUFBSUQsRUFBRSxDQUFDRSxJQUFQLENBQVksQ0FBWixFQUFlLENBQUMsR0FBaEIsQ0FBZCxDQUFaO0FBQ0FILElBQUFBLEtBQUssQ0FBQ0ksZ0JBQU4sQ0FBdUIsSUFBdkI7QUFDQSxTQUFLTCxNQUFMLEdBQWNDLEtBQWQsQ0FIaUIsQ0FJakI7O0FBQ0EsUUFBSUssR0FBRyxHQUFHLElBQUlKLEVBQUUsQ0FBQ0ssaUJBQVAsRUFBVjtBQUNBRCxJQUFBQSxHQUFHLENBQUNFLE1BQUosR0FBYSxHQUFiO0FBQ0FGLElBQUFBLEdBQUcsQ0FBQ0csZUFBSixHQUFzQixHQUF0QjtBQUNBSCxJQUFBQSxHQUFHLENBQUNJLGVBQUosR0FBc0IsQ0FBdEI7QUFDQTs7Ozs7Ozs7Ozs7OztBQVlBLFNBQUtDLFVBQUwsR0FBa0IsS0FBS1gsTUFBTCxDQUFZWSxvQkFBWixDQUFpQ04sR0FBakMsQ0FBbEI7O0FBQ0EsU0FBS08sYUFBTDtBQUNBOztBQUNELE9BQUtDLFFBQUwsR0FBZ0IsSUFBaEI7QUFDQSxDQTNCRDs7QUE0QkFaLEVBQUUsQ0FBQ2EsSUFBSCxDQUFRbEIsU0FBUixDQUFrQm1CLGFBQWxCLEdBQWtDLFVBQVVDLGNBQVYsRUFBMEJULE1BQTFCLEVBQWtDVSxXQUFsQyxFQUErQ0MsYUFBL0MsRUFBNkQ7QUFDOUY7QUFDQSxNQUFJQyxLQUFLLEdBQUcsSUFBSXpCLEVBQUUsQ0FBQzBCLEtBQVAsQ0FBYSxHQUFiLEVBQWlCLEdBQWpCLEVBQXFCLEdBQXJCLENBQVo7O0FBQ0EsT0FBSSxJQUFJQyxDQUFDLEdBQUMsQ0FBVixFQUFhQSxDQUFDLEdBQUdILGFBQWpCLEVBQWdDRyxDQUFDLEVBQWpDLEVBQXFDO0FBQ3BDLFFBQUlDLElBQUksR0FBR04sY0FBYyxDQUFDSyxDQUFELENBQXpCO0FBQ0EsU0FBS0UsZUFBTCxDQUFxQkQsSUFBckIsRUFBMEJmLE1BQU0sR0FBRyxHQUFuQyxFQUF1QyxDQUF2QyxFQUF5Q1ksS0FBekM7QUFDRztBQUNKLENBUEQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImNjLlBoeXNpY3NNYW5hZ2VyLnByb3RvdHlwZS5zdGFydCA9IGZ1bmN0aW9uKCl7XHJcblx0aWYgKENDX0VESVRPUikgcmV0dXJuO1xyXG5cdGlmICghdGhpcy5fd29ybGQpIHtcclxuXHRcdHZhciB3b3JsZCA9IG5ldyBiMi5Xb3JsZCggbmV3IGIyLlZlYzIoMCwgLTkuNSkgKTtcclxuXHRcdHdvcmxkLlNldEFsbG93U2xlZXBpbmcodHJ1ZSk7XHJcblx0XHR0aGlzLl93b3JsZCA9IHdvcmxkO1xyXG5cdFx0Ly9saXF1aWQg57KS5a2QXHJcblx0XHR2YXIgcHNkID0gbmV3IGIyLlBhcnRpY2xlU3lzdGVtRGVmKCk7XHJcblx0XHRwc2QucmFkaXVzID0gMC4zO1xyXG5cdFx0cHNkLmRhbXBpbmdTdHJlbmd0aCA9IDEuNTtcclxuXHRcdHBzZC52aXNjb3VzU3RyZW5ndGggPSAwO1xyXG5cdFx0LypcclxuXHRcdGlmKEdsb2JhbERhdGEuR2FtZUluZm9Db25maWcuZ2FtZVR5cGUgPT0gMSl7XHJcblx0XHRcdHBzZC5kYW1waW5nU3RyZW5ndGggPSAxLjU7XHJcblx0XHRcdHBzZC52aXNjb3VzU3RyZW5ndGggPSAwO1xyXG5cdFx0fWVsc2V7XHJcblx0XHRcdHBzZC5kYW1waW5nU3RyZW5ndGggPSAyO1xyXG5cdFx0XHRwc2QudmlzY291c1N0cmVuZ3RoID0gMDtcclxuXHRcdFx0Ly9wc2QuZWxhc3RpY1N0cmVuZ3RoID0gMjtcclxuXHRcdFx0Ly9wc2QucG93ZGVyU3RyZW5ndGggPSAxO1xyXG5cdFx0XHQvL3BzZC5ncmF2aXR5U2NhbGUgPSAxLjU7XHJcblx0XHR9XHJcblx0XHQqL1xyXG5cdFx0dGhpcy5fcGFydGljbGVzID0gdGhpcy5fd29ybGQuQ3JlYXRlUGFydGljbGVTeXN0ZW0ocHNkKTtcclxuXHRcdHRoaXMuX2luaXRDYWxsYmFjaygpO1xyXG5cdH1cclxuXHR0aGlzLl9lbmFibGVkID0gdHJ1ZTtcclxufTtcclxuYjIuRHJhdy5wcm90b3R5cGUuRHJhd1BhcnRpY2xlcyA9IGZ1bmN0aW9uKCBwb3NpdGlvbkJ1ZmZlciwgcmFkaXVzLCBjb2xvckJ1ZmZlciwgcGFydGljbGVDb3VudCl7XHJcblx0Ly9yZXR1cm47XHJcblx0dmFyIGNvbG9yID0gbmV3IGNjLkNvbG9yKDI1NSwyNTUsMjU1KTtcclxuXHRmb3IodmFyIGk9MDsgaSA8IHBhcnRpY2xlQ291bnQ7IGkrKykge1xyXG5cdFx0bGV0IHZlYzIgPSBwb3NpdGlvbkJ1ZmZlcltpXTtcclxuXHRcdHRoaXMuRHJhd1NvbGlkQ2lyY2xlKHZlYzIscmFkaXVzICogMS4yLDAsY29sb3IpO1xyXG4gICAgfVxyXG59OyJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Water.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '1bef4MkN6VD1bgXHCNdqdm9', 'Water');
// Script/Water.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    camera_water: cc.Camera,
    sp_water_show: cc.Sprite,
    shuiLongTou: cc.Node
  },
  onLoad: function onLoad() {
    this.pymanager = cc.director.getPhysicsManager();
    this.pymanager.start();
    /*
    this.pymanager.debugDrawFlags = cc.PhysicsManager.DrawBits.e_aabbBit |
    	cc.PhysicsManager.DrawBits.e_pairBit |
    	cc.PhysicsManager.DrawBits.e_centerOfMassBit |
    	cc.PhysicsManager.DrawBits.e_jointBit |
    	cc.PhysicsManager.DrawBits.e_shapeBit //|
    	//cc.PhysicsManager.DrawBits.e_particleBit
    	;
    	*/

    var texture = new cc.RenderTexture();
    var size = this.sp_water_show.node.getContentSize();
    texture.initWithSize(size.width, size.height);
    var spriteFrame = new cc.SpriteFrame();
    spriteFrame.setTexture(texture);
    this.camera_water.targetTexture = texture;
    this.sp_water_show.spriteFrame = spriteFrame;
  },
  initParticle: function initParticle() {
    var PTM_RATIO = cc.PhysicsManager.PTM_RATIO;
    var shuiLongTouSize = this.shuiLongTou.getContentSize();
    var shuiLongTouPos = this.shuiLongTou.getPosition();
    var size = cc.winSize;
    this.particleSystem = this.pymanager._particles;
    var box = new b2.PolygonShape();
    box.SetAsBox(shuiLongTouSize.width / 2 / PTM_RATIO, shuiLongTouSize.height * 1.8 / PTM_RATIO, new b2.Vec2(0, 0), 0);
    var particleGroupDef = new b2.ParticleGroupDef();
    particleGroupDef.shape = box;
    particleGroupDef.flags = b2.waterParticle;
    particleGroupDef.position.Set((shuiLongTouPos.x + size.width / 2) / PTM_RATIO, (shuiLongTouPos.y + size.height / 2 + shuiLongTouSize.height * 1.2) / PTM_RATIO);
    this.particleGroup = this.particleSystem.CreateParticleGroup(particleGroupDef);
    var vertsCount = this.particleSystem.GetParticleCount();
    this.totalCount = vertsCount;
    this._mat = this.sp_water_show.getMaterial(0);

    this._mat.setProperty('resolution', new Float32Array(4));

    this._mat.setProperty('metaballs', new Float32Array(vertsCount * 4));

    console.log(vertsCount);
  },
  generateWater: function generateWater() {
    var _this = this;

    this.resetWater();
    setTimeout(function () {
      _this.initParticle();

      _this.schedule(_this.scheduleWater, 0.01);
    }, 500);
  },
  scheduleWater: function scheduleWater() {
    var PTM_RATIO = cc.PhysicsManager.PTM_RATIO;

    if (this.particleSystem != null) {
      var tmp = [];
      var vertsCount = this.particleSystem.GetParticleCount();
      var posVerts = this.particleSystem.GetPositionBuffer();

      for (var i = 0; i < vertsCount; i++) {
        tmp.push(posVerts[i].x * PTM_RATIO);
        tmp.push(posVerts[i].y * PTM_RATIO);
        tmp.push(0.35 * PTM_RATIO);
        tmp.push(0.0);
      }

      var size = this.shuiLongTou.getContentSize();

      if (this._mat) {
        this._mat.setProperty('resolution', [640.0, 1136.0, vertsCount, this.shuiLongTou.y - size.height / 2 + 568]);

        this._mat.setProperty('metaballs', tmp);
      }
    }
  },
  resetWater: function resetWater() {
    this.unschedule(this.scheduleWater);
    /*
    if(this._mat){
    	this._mat.setProperty('metaballs',new Float32Array(this.totalCount * 4));
    }
    */

    if (this.particleSystem != null) {
      this.particleGroup.DestroyParticles(null);
      this.particleSystem.DestroyParticleGroup(this.particleGroup);
      this.particleSystem = null;
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxXYXRlci5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsImNhbWVyYV93YXRlciIsIkNhbWVyYSIsInNwX3dhdGVyX3Nob3ciLCJTcHJpdGUiLCJzaHVpTG9uZ1RvdSIsIk5vZGUiLCJvbkxvYWQiLCJweW1hbmFnZXIiLCJkaXJlY3RvciIsImdldFBoeXNpY3NNYW5hZ2VyIiwic3RhcnQiLCJ0ZXh0dXJlIiwiUmVuZGVyVGV4dHVyZSIsInNpemUiLCJub2RlIiwiZ2V0Q29udGVudFNpemUiLCJpbml0V2l0aFNpemUiLCJ3aWR0aCIsImhlaWdodCIsInNwcml0ZUZyYW1lIiwiU3ByaXRlRnJhbWUiLCJzZXRUZXh0dXJlIiwidGFyZ2V0VGV4dHVyZSIsImluaXRQYXJ0aWNsZSIsIlBUTV9SQVRJTyIsIlBoeXNpY3NNYW5hZ2VyIiwic2h1aUxvbmdUb3VTaXplIiwic2h1aUxvbmdUb3VQb3MiLCJnZXRQb3NpdGlvbiIsIndpblNpemUiLCJwYXJ0aWNsZVN5c3RlbSIsIl9wYXJ0aWNsZXMiLCJib3giLCJiMiIsIlBvbHlnb25TaGFwZSIsIlNldEFzQm94IiwiVmVjMiIsInBhcnRpY2xlR3JvdXBEZWYiLCJQYXJ0aWNsZUdyb3VwRGVmIiwic2hhcGUiLCJmbGFncyIsIndhdGVyUGFydGljbGUiLCJwb3NpdGlvbiIsIlNldCIsIngiLCJ5IiwicGFydGljbGVHcm91cCIsIkNyZWF0ZVBhcnRpY2xlR3JvdXAiLCJ2ZXJ0c0NvdW50IiwiR2V0UGFydGljbGVDb3VudCIsInRvdGFsQ291bnQiLCJfbWF0IiwiZ2V0TWF0ZXJpYWwiLCJzZXRQcm9wZXJ0eSIsIkZsb2F0MzJBcnJheSIsImNvbnNvbGUiLCJsb2ciLCJnZW5lcmF0ZVdhdGVyIiwicmVzZXRXYXRlciIsInNldFRpbWVvdXQiLCJzY2hlZHVsZSIsInNjaGVkdWxlV2F0ZXIiLCJ0bXAiLCJwb3NWZXJ0cyIsIkdldFBvc2l0aW9uQnVmZmVyIiwiaSIsInB1c2giLCJ1bnNjaGVkdWxlIiwiRGVzdHJveVBhcnRpY2xlcyIsIkRlc3Ryb3lQYXJ0aWNsZUdyb3VwIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDZEMsSUFBQUEsWUFBWSxFQUFFSixFQUFFLENBQUNLLE1BREg7QUFFZEMsSUFBQUEsYUFBYSxFQUFFTixFQUFFLENBQUNPLE1BRko7QUFHZEMsSUFBQUEsV0FBVyxFQUFDUixFQUFFLENBQUNTO0FBSEQsR0FIUDtBQVFMQyxFQUFBQSxNQVJLLG9CQVFJO0FBQ1gsU0FBS0MsU0FBTCxHQUFpQlgsRUFBRSxDQUFDWSxRQUFILENBQVlDLGlCQUFaLEVBQWpCO0FBQ0EsU0FBS0YsU0FBTCxDQUFlRyxLQUFmO0FBQ0E7Ozs7Ozs7Ozs7QUFTQSxRQUFNQyxPQUFPLEdBQUcsSUFBSWYsRUFBRSxDQUFDZ0IsYUFBUCxFQUFoQjtBQUNBLFFBQUlDLElBQUksR0FBRyxLQUFLWCxhQUFMLENBQW1CWSxJQUFuQixDQUF3QkMsY0FBeEIsRUFBWDtBQUNNSixJQUFBQSxPQUFPLENBQUNLLFlBQVIsQ0FBcUJILElBQUksQ0FBQ0ksS0FBMUIsRUFBaUNKLElBQUksQ0FBQ0ssTUFBdEM7QUFFQSxRQUFNQyxXQUFXLEdBQUcsSUFBSXZCLEVBQUUsQ0FBQ3dCLFdBQVAsRUFBcEI7QUFDQUQsSUFBQUEsV0FBVyxDQUFDRSxVQUFaLENBQXVCVixPQUF2QjtBQUNBLFNBQUtYLFlBQUwsQ0FBa0JzQixhQUFsQixHQUFrQ1gsT0FBbEM7QUFDQSxTQUFLVCxhQUFMLENBQW1CaUIsV0FBbkIsR0FBaUNBLFdBQWpDO0FBQ0gsR0E1Qkk7QUE2QlJJLEVBQUFBLFlBN0JRLDBCQTZCTTtBQUNiLFFBQUlDLFNBQVMsR0FBRzVCLEVBQUUsQ0FBQzZCLGNBQUgsQ0FBa0JELFNBQWxDO0FBQ0EsUUFBSUUsZUFBZSxHQUFHLEtBQUt0QixXQUFMLENBQWlCVyxjQUFqQixFQUF0QjtBQUNBLFFBQUlZLGNBQWMsR0FBRyxLQUFLdkIsV0FBTCxDQUFpQndCLFdBQWpCLEVBQXJCO0FBQ0EsUUFBSWYsSUFBSSxHQUFHakIsRUFBRSxDQUFDaUMsT0FBZDtBQUNBLFNBQUtDLGNBQUwsR0FBc0IsS0FBS3ZCLFNBQUwsQ0FBZXdCLFVBQXJDO0FBQ0EsUUFBSUMsR0FBRyxHQUFHLElBQUlDLEVBQUUsQ0FBQ0MsWUFBUCxFQUFWO0FBQ0FGLElBQUFBLEdBQUcsQ0FBQ0csUUFBSixDQUFhVCxlQUFlLENBQUNULEtBQWhCLEdBQXNCLENBQXRCLEdBQXdCTyxTQUFyQyxFQUFpREUsZUFBZSxDQUFDUixNQUFoQixHQUF5QixHQUExQixHQUErQk0sU0FBL0UsRUFBMEYsSUFBSVMsRUFBRSxDQUFDRyxJQUFQLENBQVksQ0FBWixFQUFlLENBQWYsQ0FBMUYsRUFBNkcsQ0FBN0c7QUFFQSxRQUFJQyxnQkFBZ0IsR0FBRyxJQUFJSixFQUFFLENBQUNLLGdCQUFQLEVBQXZCO0FBQ0FELElBQUFBLGdCQUFnQixDQUFDRSxLQUFqQixHQUF5QlAsR0FBekI7QUFDQUssSUFBQUEsZ0JBQWdCLENBQUNHLEtBQWpCLEdBQXlCUCxFQUFFLENBQUNRLGFBQTVCO0FBQ0FKLElBQUFBLGdCQUFnQixDQUFDSyxRQUFqQixDQUEwQkMsR0FBMUIsQ0FBOEIsQ0FBQ2hCLGNBQWMsQ0FBQ2lCLENBQWYsR0FBbUIvQixJQUFJLENBQUNJLEtBQUwsR0FBVyxDQUEvQixJQUFrQ08sU0FBaEUsRUFBMEUsQ0FBQ0csY0FBYyxDQUFDa0IsQ0FBZixHQUFtQmhDLElBQUksQ0FBQ0ssTUFBTCxHQUFZLENBQS9CLEdBQW1DUSxlQUFlLENBQUNSLE1BQWhCLEdBQXdCLEdBQTVELElBQWlFTSxTQUEzSTtBQUNBLFNBQUtzQixhQUFMLEdBQXFCLEtBQUtoQixjQUFMLENBQW9CaUIsbUJBQXBCLENBQXdDVixnQkFBeEMsQ0FBckI7QUFDQSxRQUFJVyxVQUFVLEdBQUcsS0FBS2xCLGNBQUwsQ0FBb0JtQixnQkFBcEIsRUFBakI7QUFDQSxTQUFLQyxVQUFMLEdBQWtCRixVQUFsQjtBQUNBLFNBQUtHLElBQUwsR0FBWSxLQUFLakQsYUFBTCxDQUFtQmtELFdBQW5CLENBQStCLENBQS9CLENBQVo7O0FBQ0EsU0FBS0QsSUFBTCxDQUFVRSxXQUFWLENBQXNCLFlBQXRCLEVBQW1DLElBQUlDLFlBQUosQ0FBaUIsQ0FBakIsQ0FBbkM7O0FBQ0EsU0FBS0gsSUFBTCxDQUFVRSxXQUFWLENBQXNCLFdBQXRCLEVBQWtDLElBQUlDLFlBQUosQ0FBaUJOLFVBQVUsR0FBRyxDQUE5QixDQUFsQzs7QUFDQU8sSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVlSLFVBQVo7QUFDQSxHQWpETztBQWtETFMsRUFBQUEsYUFsREssMkJBa0RXO0FBQUE7O0FBQ1osU0FBS0MsVUFBTDtBQUNOQyxJQUFBQSxVQUFVLENBQUMsWUFBSTtBQUNkLE1BQUEsS0FBSSxDQUFDcEMsWUFBTDs7QUFDQSxNQUFBLEtBQUksQ0FBQ3FDLFFBQUwsQ0FBYyxLQUFJLENBQUNDLGFBQW5CLEVBQWtDLElBQWxDO0FBQ0EsS0FIUyxFQUdSLEdBSFEsQ0FBVjtBQUlHLEdBeERJO0FBeURMQSxFQUFBQSxhQXpESywyQkF5RFc7QUFDbEIsUUFBSXJDLFNBQVMsR0FBRzVCLEVBQUUsQ0FBQzZCLGNBQUgsQ0FBa0JELFNBQWxDOztBQUNBLFFBQUcsS0FBS00sY0FBTCxJQUF1QixJQUExQixFQUErQjtBQUM5QixVQUFJZ0MsR0FBRyxHQUFHLEVBQVY7QUFDQSxVQUFJZCxVQUFVLEdBQUcsS0FBS2xCLGNBQUwsQ0FBb0JtQixnQkFBcEIsRUFBakI7QUFDQSxVQUFJYyxRQUFRLEdBQUcsS0FBS2pDLGNBQUwsQ0FBb0JrQyxpQkFBcEIsRUFBZjs7QUFDQSxXQUFLLElBQUlDLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdqQixVQUFwQixFQUFnQ2lCLENBQUMsRUFBakMsRUFBcUM7QUFDcENILFFBQUFBLEdBQUcsQ0FBQ0ksSUFBSixDQUFTSCxRQUFRLENBQUNFLENBQUQsQ0FBUixDQUFZckIsQ0FBWixHQUFnQnBCLFNBQXpCO0FBQ0FzQyxRQUFBQSxHQUFHLENBQUNJLElBQUosQ0FBU0gsUUFBUSxDQUFDRSxDQUFELENBQVIsQ0FBWXBCLENBQVosR0FBZ0JyQixTQUF6QjtBQUNBc0MsUUFBQUEsR0FBRyxDQUFDSSxJQUFKLENBQVMsT0FBTzFDLFNBQWhCO0FBQ0FzQyxRQUFBQSxHQUFHLENBQUNJLElBQUosQ0FBUyxHQUFUO0FBQ0E7O0FBQ0QsVUFBSXJELElBQUksR0FBRyxLQUFLVCxXQUFMLENBQWlCVyxjQUFqQixFQUFYOztBQUNBLFVBQUcsS0FBS29DLElBQVIsRUFBYTtBQUNaLGFBQUtBLElBQUwsQ0FBVUUsV0FBVixDQUFzQixZQUF0QixFQUFtQyxDQUFDLEtBQUQsRUFBTyxNQUFQLEVBQWNMLFVBQWQsRUFBeUIsS0FBSzVDLFdBQUwsQ0FBaUJ5QyxDQUFqQixHQUFxQmhDLElBQUksQ0FBQ0ssTUFBTCxHQUFZLENBQWpDLEdBQXFDLEdBQTlELENBQW5DOztBQUNBLGFBQUtpQyxJQUFMLENBQVVFLFdBQVYsQ0FBc0IsV0FBdEIsRUFBa0NTLEdBQWxDO0FBQ0E7QUFDRDtBQUNFLEdBM0VJO0FBNkVMSixFQUFBQSxVQTdFSyx3QkE2RVE7QUFDVCxTQUFLUyxVQUFMLENBQWdCLEtBQUtOLGFBQXJCO0FBQ047Ozs7OztBQUtBLFFBQUcsS0FBSy9CLGNBQUwsSUFBdUIsSUFBMUIsRUFBK0I7QUFDOUIsV0FBS2dCLGFBQUwsQ0FBbUJzQixnQkFBbkIsQ0FBb0MsSUFBcEM7QUFDQSxXQUFLdEMsY0FBTCxDQUFvQnVDLG9CQUFwQixDQUF5QyxLQUFLdkIsYUFBOUM7QUFDQSxXQUFLaEIsY0FBTCxHQUFzQixJQUF0QjtBQUNBO0FBQ0U7QUF6RkksQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuXHRcdGNhbWVyYV93YXRlcjogY2MuQ2FtZXJhLFxyXG5cdFx0c3Bfd2F0ZXJfc2hvdzogY2MuU3ByaXRlLFxyXG5cdFx0c2h1aUxvbmdUb3U6Y2MuTm9kZSxcclxuICAgIH0sXHJcbiAgICBvbkxvYWQoKSB7XHJcblx0XHR0aGlzLnB5bWFuYWdlciA9IGNjLmRpcmVjdG9yLmdldFBoeXNpY3NNYW5hZ2VyKCk7XHJcblx0XHR0aGlzLnB5bWFuYWdlci5zdGFydCgpXHJcblx0XHQvKlxyXG5cdFx0dGhpcy5weW1hbmFnZXIuZGVidWdEcmF3RmxhZ3MgPSBjYy5QaHlzaWNzTWFuYWdlci5EcmF3Qml0cy5lX2FhYmJCaXQgfFxyXG5cdFx0XHRjYy5QaHlzaWNzTWFuYWdlci5EcmF3Qml0cy5lX3BhaXJCaXQgfFxyXG5cdFx0XHRjYy5QaHlzaWNzTWFuYWdlci5EcmF3Qml0cy5lX2NlbnRlck9mTWFzc0JpdCB8XHJcblx0XHRcdGNjLlBoeXNpY3NNYW5hZ2VyLkRyYXdCaXRzLmVfam9pbnRCaXQgfFxyXG5cdFx0XHRjYy5QaHlzaWNzTWFuYWdlci5EcmF3Qml0cy5lX3NoYXBlQml0IC8vfFxyXG5cdFx0XHQvL2NjLlBoeXNpY3NNYW5hZ2VyLkRyYXdCaXRzLmVfcGFydGljbGVCaXRcclxuXHRcdFx0O1xyXG5cdFx0XHQqL1xyXG5cdFx0Y29uc3QgdGV4dHVyZSA9IG5ldyBjYy5SZW5kZXJUZXh0dXJlKCk7XHJcblx0XHRsZXQgc2l6ZSA9IHRoaXMuc3Bfd2F0ZXJfc2hvdy5ub2RlLmdldENvbnRlbnRTaXplKCk7XHJcbiAgICAgICAgdGV4dHVyZS5pbml0V2l0aFNpemUoc2l6ZS53aWR0aCwgc2l6ZS5oZWlnaHQpO1xyXG5cdFx0XHJcbiAgICAgICAgY29uc3Qgc3ByaXRlRnJhbWUgPSBuZXcgY2MuU3ByaXRlRnJhbWUoKTtcclxuICAgICAgICBzcHJpdGVGcmFtZS5zZXRUZXh0dXJlKHRleHR1cmUpO1xyXG4gICAgICAgIHRoaXMuY2FtZXJhX3dhdGVyLnRhcmdldFRleHR1cmUgPSB0ZXh0dXJlO1xyXG4gICAgICAgIHRoaXMuc3Bfd2F0ZXJfc2hvdy5zcHJpdGVGcmFtZSA9IHNwcml0ZUZyYW1lO1xyXG4gICAgfSxcclxuXHRpbml0UGFydGljbGUoKXtcclxuXHRcdGxldCBQVE1fUkFUSU8gPSBjYy5QaHlzaWNzTWFuYWdlci5QVE1fUkFUSU87XHJcblx0XHR2YXIgc2h1aUxvbmdUb3VTaXplID0gdGhpcy5zaHVpTG9uZ1RvdS5nZXRDb250ZW50U2l6ZSgpO1xyXG5cdFx0dmFyIHNodWlMb25nVG91UG9zID0gdGhpcy5zaHVpTG9uZ1RvdS5nZXRQb3NpdGlvbigpO1xyXG5cdFx0dmFyIHNpemUgPSBjYy53aW5TaXplO1xyXG5cdFx0dGhpcy5wYXJ0aWNsZVN5c3RlbSA9IHRoaXMucHltYW5hZ2VyLl9wYXJ0aWNsZXM7XHJcblx0XHR2YXIgYm94ID0gbmV3IGIyLlBvbHlnb25TaGFwZSgpO1xyXG5cdFx0Ym94LlNldEFzQm94KHNodWlMb25nVG91U2l6ZS53aWR0aC8yL1BUTV9SQVRJTywgKHNodWlMb25nVG91U2l6ZS5oZWlnaHQgKiAxLjgpL1BUTV9SQVRJTywgbmV3IGIyLlZlYzIoMCwgMCksIDApO1xyXG5cclxuXHRcdHZhciBwYXJ0aWNsZUdyb3VwRGVmID0gbmV3IGIyLlBhcnRpY2xlR3JvdXBEZWYoKTtcclxuXHRcdHBhcnRpY2xlR3JvdXBEZWYuc2hhcGUgPSBib3g7XHJcblx0XHRwYXJ0aWNsZUdyb3VwRGVmLmZsYWdzID0gYjIud2F0ZXJQYXJ0aWNsZTtcclxuXHRcdHBhcnRpY2xlR3JvdXBEZWYucG9zaXRpb24uU2V0KChzaHVpTG9uZ1RvdVBvcy54ICsgc2l6ZS53aWR0aC8yKS9QVE1fUkFUSU8sKHNodWlMb25nVG91UG9zLnkgKyBzaXplLmhlaWdodC8yICsgc2h1aUxvbmdUb3VTaXplLmhlaWdodCogMS4yKS9QVE1fUkFUSU8pO1xyXG5cdFx0dGhpcy5wYXJ0aWNsZUdyb3VwID0gdGhpcy5wYXJ0aWNsZVN5c3RlbS5DcmVhdGVQYXJ0aWNsZUdyb3VwKHBhcnRpY2xlR3JvdXBEZWYpO1xyXG5cdFx0bGV0IHZlcnRzQ291bnQgPSB0aGlzLnBhcnRpY2xlU3lzdGVtLkdldFBhcnRpY2xlQ291bnQoKTtcclxuXHRcdHRoaXMudG90YWxDb3VudCA9IHZlcnRzQ291bnQ7XHJcblx0XHR0aGlzLl9tYXQgPSB0aGlzLnNwX3dhdGVyX3Nob3cuZ2V0TWF0ZXJpYWwoMCk7XHJcblx0XHR0aGlzLl9tYXQuc2V0UHJvcGVydHkoJ3Jlc29sdXRpb24nLG5ldyBGbG9hdDMyQXJyYXkoNCkpO1xyXG5cdFx0dGhpcy5fbWF0LnNldFByb3BlcnR5KCdtZXRhYmFsbHMnLG5ldyBGbG9hdDMyQXJyYXkodmVydHNDb3VudCAqIDQpKTtcclxuXHRcdGNvbnNvbGUubG9nKHZlcnRzQ291bnQpO1xyXG5cdH0sXHJcbiAgICBnZW5lcmF0ZVdhdGVyKCkge1xyXG4gICAgICAgIHRoaXMucmVzZXRXYXRlcigpO1xyXG5cdFx0c2V0VGltZW91dCgoKT0+e1xyXG5cdFx0XHR0aGlzLmluaXRQYXJ0aWNsZSgpO1xyXG5cdFx0XHR0aGlzLnNjaGVkdWxlKHRoaXMuc2NoZWR1bGVXYXRlciwgMC4wMSk7XHJcblx0XHR9LDUwMCk7XHJcbiAgICB9LFxyXG4gICAgc2NoZWR1bGVXYXRlcigpIHtcclxuXHRcdGxldCBQVE1fUkFUSU8gPSBjYy5QaHlzaWNzTWFuYWdlci5QVE1fUkFUSU87XHJcblx0XHRpZih0aGlzLnBhcnRpY2xlU3lzdGVtICE9IG51bGwpe1xyXG5cdFx0XHRsZXQgdG1wID0gW107XHJcblx0XHRcdGxldCB2ZXJ0c0NvdW50ID0gdGhpcy5wYXJ0aWNsZVN5c3RlbS5HZXRQYXJ0aWNsZUNvdW50KCk7XHJcblx0XHRcdGxldCBwb3NWZXJ0cyA9IHRoaXMucGFydGljbGVTeXN0ZW0uR2V0UG9zaXRpb25CdWZmZXIoKTtcclxuXHRcdFx0Zm9yIChsZXQgaSA9IDA7IGkgPCB2ZXJ0c0NvdW50OyBpKyspIHtcclxuXHRcdFx0XHR0bXAucHVzaChwb3NWZXJ0c1tpXS54ICogUFRNX1JBVElPKTtcclxuXHRcdFx0XHR0bXAucHVzaChwb3NWZXJ0c1tpXS55ICogUFRNX1JBVElPKTtcclxuXHRcdFx0XHR0bXAucHVzaCgwLjM1ICogUFRNX1JBVElPKTtcclxuXHRcdFx0XHR0bXAucHVzaCgwLjApO1xyXG5cdFx0XHR9XHJcblx0XHRcdGxldCBzaXplID0gdGhpcy5zaHVpTG9uZ1RvdS5nZXRDb250ZW50U2l6ZSgpO1xyXG5cdFx0XHRpZih0aGlzLl9tYXQpe1xyXG5cdFx0XHRcdHRoaXMuX21hdC5zZXRQcm9wZXJ0eSgncmVzb2x1dGlvbicsWzY0MC4wLDExMzYuMCx2ZXJ0c0NvdW50LHRoaXMuc2h1aUxvbmdUb3UueSAtIHNpemUuaGVpZ2h0LzIgKyA1NjhdKTtcclxuXHRcdFx0XHR0aGlzLl9tYXQuc2V0UHJvcGVydHkoJ21ldGFiYWxscycsdG1wKTtcclxuXHRcdFx0fVxyXG5cdFx0fVxyXG4gICAgfSxcclxuXHJcbiAgICByZXNldFdhdGVyKCkge1xyXG4gICAgICAgIHRoaXMudW5zY2hlZHVsZSh0aGlzLnNjaGVkdWxlV2F0ZXIpO1xyXG5cdFx0LypcclxuXHRcdGlmKHRoaXMuX21hdCl7XHJcblx0XHRcdHRoaXMuX21hdC5zZXRQcm9wZXJ0eSgnbWV0YWJhbGxzJyxuZXcgRmxvYXQzMkFycmF5KHRoaXMudG90YWxDb3VudCAqIDQpKTtcclxuXHRcdH1cclxuXHRcdCovXHJcblx0XHRpZih0aGlzLnBhcnRpY2xlU3lzdGVtICE9IG51bGwpe1xyXG5cdFx0XHR0aGlzLnBhcnRpY2xlR3JvdXAuRGVzdHJveVBhcnRpY2xlcyhudWxsKTtcclxuXHRcdFx0dGhpcy5wYXJ0aWNsZVN5c3RlbS5EZXN0cm95UGFydGljbGVHcm91cCh0aGlzLnBhcnRpY2xlR3JvdXApO1xyXG5cdFx0XHR0aGlzLnBhcnRpY2xlU3lzdGVtID0gbnVsbDtcclxuXHRcdH1cclxuICAgIH1cclxufSk7XHJcbiJdfQ==
//------QC-SOURCE-SPLIT------
