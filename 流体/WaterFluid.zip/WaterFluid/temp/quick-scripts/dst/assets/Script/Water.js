
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Water.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '1bef4MkN6VD1bgXHCNdqdm9', 'Water');
// Script/Water.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    camera_water: cc.Camera,
    sp_water_show: cc.Sprite,
    shuiLongTou: cc.Node
  },
  onLoad: function onLoad() {
    this.pymanager = cc.director.getPhysicsManager();
    this.pymanager.start();
    /*
    this.pymanager.debugDrawFlags = cc.PhysicsManager.DrawBits.e_aabbBit |
    	cc.PhysicsManager.DrawBits.e_pairBit |
    	cc.PhysicsManager.DrawBits.e_centerOfMassBit |
    	cc.PhysicsManager.DrawBits.e_jointBit |
    	cc.PhysicsManager.DrawBits.e_shapeBit //|
    	//cc.PhysicsManager.DrawBits.e_particleBit
    	;
    	*/

    var texture = new cc.RenderTexture();
    var size = this.sp_water_show.node.getContentSize();
    texture.initWithSize(size.width, size.height);
    var spriteFrame = new cc.SpriteFrame();
    spriteFrame.setTexture(texture);
    this.camera_water.targetTexture = texture;
    this.sp_water_show.spriteFrame = spriteFrame;
  },
  initParticle: function initParticle() {
    var PTM_RATIO = cc.PhysicsManager.PTM_RATIO;
    var shuiLongTouSize = this.shuiLongTou.getContentSize();
    var shuiLongTouPos = this.shuiLongTou.getPosition();
    var size = cc.winSize;
    this.particleSystem = this.pymanager._particles;
    var box = new b2.PolygonShape();
    box.SetAsBox(shuiLongTouSize.width / 2 / PTM_RATIO, shuiLongTouSize.height * 1.8 / PTM_RATIO, new b2.Vec2(0, 0), 0);
    var particleGroupDef = new b2.ParticleGroupDef();
    particleGroupDef.shape = box;
    particleGroupDef.flags = b2.waterParticle;
    particleGroupDef.position.Set((shuiLongTouPos.x + size.width / 2) / PTM_RATIO, (shuiLongTouPos.y + size.height / 2 + shuiLongTouSize.height * 1.2) / PTM_RATIO);
    this.particleGroup = this.particleSystem.CreateParticleGroup(particleGroupDef);
    var vertsCount = this.particleSystem.GetParticleCount();
    this.totalCount = vertsCount;
    this._mat = this.sp_water_show.getMaterial(0);

    this._mat.setProperty('resolution', new Float32Array(4));

    this._mat.setProperty('metaballs', new Float32Array(vertsCount * 4));

    console.log(vertsCount);
  },
  generateWater: function generateWater() {
    var _this = this;

    this.resetWater();
    setTimeout(function () {
      _this.initParticle();

      _this.schedule(_this.scheduleWater, 0.01);
    }, 500);
  },
  scheduleWater: function scheduleWater() {
    var PTM_RATIO = cc.PhysicsManager.PTM_RATIO;

    if (this.particleSystem != null) {
      var tmp = [];
      var vertsCount = this.particleSystem.GetParticleCount();
      var posVerts = this.particleSystem.GetPositionBuffer();

      for (var i = 0; i < vertsCount; i++) {
        tmp.push(posVerts[i].x * PTM_RATIO);
        tmp.push(posVerts[i].y * PTM_RATIO);
        tmp.push(0.35 * PTM_RATIO);
        tmp.push(0.0);
      }

      var size = this.shuiLongTou.getContentSize();

      if (this._mat) {
        this._mat.setProperty('resolution', [640.0, 1136.0, vertsCount, this.shuiLongTou.y - size.height / 2 + 568]);

        this._mat.setProperty('metaballs', tmp);
      }
    }
  },
  resetWater: function resetWater() {
    this.unschedule(this.scheduleWater);
    /*
    if(this._mat){
    	this._mat.setProperty('metaballs',new Float32Array(this.totalCount * 4));
    }
    */

    if (this.particleSystem != null) {
      this.particleGroup.DestroyParticles(null);
      this.particleSystem.DestroyParticleGroup(this.particleGroup);
      this.particleSystem = null;
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxXYXRlci5qcyJdLCJuYW1lcyI6WyJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsImNhbWVyYV93YXRlciIsIkNhbWVyYSIsInNwX3dhdGVyX3Nob3ciLCJTcHJpdGUiLCJzaHVpTG9uZ1RvdSIsIk5vZGUiLCJvbkxvYWQiLCJweW1hbmFnZXIiLCJkaXJlY3RvciIsImdldFBoeXNpY3NNYW5hZ2VyIiwic3RhcnQiLCJ0ZXh0dXJlIiwiUmVuZGVyVGV4dHVyZSIsInNpemUiLCJub2RlIiwiZ2V0Q29udGVudFNpemUiLCJpbml0V2l0aFNpemUiLCJ3aWR0aCIsImhlaWdodCIsInNwcml0ZUZyYW1lIiwiU3ByaXRlRnJhbWUiLCJzZXRUZXh0dXJlIiwidGFyZ2V0VGV4dHVyZSIsImluaXRQYXJ0aWNsZSIsIlBUTV9SQVRJTyIsIlBoeXNpY3NNYW5hZ2VyIiwic2h1aUxvbmdUb3VTaXplIiwic2h1aUxvbmdUb3VQb3MiLCJnZXRQb3NpdGlvbiIsIndpblNpemUiLCJwYXJ0aWNsZVN5c3RlbSIsIl9wYXJ0aWNsZXMiLCJib3giLCJiMiIsIlBvbHlnb25TaGFwZSIsIlNldEFzQm94IiwiVmVjMiIsInBhcnRpY2xlR3JvdXBEZWYiLCJQYXJ0aWNsZUdyb3VwRGVmIiwic2hhcGUiLCJmbGFncyIsIndhdGVyUGFydGljbGUiLCJwb3NpdGlvbiIsIlNldCIsIngiLCJ5IiwicGFydGljbGVHcm91cCIsIkNyZWF0ZVBhcnRpY2xlR3JvdXAiLCJ2ZXJ0c0NvdW50IiwiR2V0UGFydGljbGVDb3VudCIsInRvdGFsQ291bnQiLCJfbWF0IiwiZ2V0TWF0ZXJpYWwiLCJzZXRQcm9wZXJ0eSIsIkZsb2F0MzJBcnJheSIsImNvbnNvbGUiLCJsb2ciLCJnZW5lcmF0ZVdhdGVyIiwicmVzZXRXYXRlciIsInNldFRpbWVvdXQiLCJzY2hlZHVsZSIsInNjaGVkdWxlV2F0ZXIiLCJ0bXAiLCJwb3NWZXJ0cyIsIkdldFBvc2l0aW9uQnVmZmVyIiwiaSIsInB1c2giLCJ1bnNjaGVkdWxlIiwiRGVzdHJveVBhcnRpY2xlcyIsIkRlc3Ryb3lQYXJ0aWNsZUdyb3VwIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDZEMsSUFBQUEsWUFBWSxFQUFFSixFQUFFLENBQUNLLE1BREg7QUFFZEMsSUFBQUEsYUFBYSxFQUFFTixFQUFFLENBQUNPLE1BRko7QUFHZEMsSUFBQUEsV0FBVyxFQUFDUixFQUFFLENBQUNTO0FBSEQsR0FIUDtBQVFMQyxFQUFBQSxNQVJLLG9CQVFJO0FBQ1gsU0FBS0MsU0FBTCxHQUFpQlgsRUFBRSxDQUFDWSxRQUFILENBQVlDLGlCQUFaLEVBQWpCO0FBQ0EsU0FBS0YsU0FBTCxDQUFlRyxLQUFmO0FBQ0E7Ozs7Ozs7Ozs7QUFTQSxRQUFNQyxPQUFPLEdBQUcsSUFBSWYsRUFBRSxDQUFDZ0IsYUFBUCxFQUFoQjtBQUNBLFFBQUlDLElBQUksR0FBRyxLQUFLWCxhQUFMLENBQW1CWSxJQUFuQixDQUF3QkMsY0FBeEIsRUFBWDtBQUNNSixJQUFBQSxPQUFPLENBQUNLLFlBQVIsQ0FBcUJILElBQUksQ0FBQ0ksS0FBMUIsRUFBaUNKLElBQUksQ0FBQ0ssTUFBdEM7QUFFQSxRQUFNQyxXQUFXLEdBQUcsSUFBSXZCLEVBQUUsQ0FBQ3dCLFdBQVAsRUFBcEI7QUFDQUQsSUFBQUEsV0FBVyxDQUFDRSxVQUFaLENBQXVCVixPQUF2QjtBQUNBLFNBQUtYLFlBQUwsQ0FBa0JzQixhQUFsQixHQUFrQ1gsT0FBbEM7QUFDQSxTQUFLVCxhQUFMLENBQW1CaUIsV0FBbkIsR0FBaUNBLFdBQWpDO0FBQ0gsR0E1Qkk7QUE2QlJJLEVBQUFBLFlBN0JRLDBCQTZCTTtBQUNiLFFBQUlDLFNBQVMsR0FBRzVCLEVBQUUsQ0FBQzZCLGNBQUgsQ0FBa0JELFNBQWxDO0FBQ0EsUUFBSUUsZUFBZSxHQUFHLEtBQUt0QixXQUFMLENBQWlCVyxjQUFqQixFQUF0QjtBQUNBLFFBQUlZLGNBQWMsR0FBRyxLQUFLdkIsV0FBTCxDQUFpQndCLFdBQWpCLEVBQXJCO0FBQ0EsUUFBSWYsSUFBSSxHQUFHakIsRUFBRSxDQUFDaUMsT0FBZDtBQUNBLFNBQUtDLGNBQUwsR0FBc0IsS0FBS3ZCLFNBQUwsQ0FBZXdCLFVBQXJDO0FBQ0EsUUFBSUMsR0FBRyxHQUFHLElBQUlDLEVBQUUsQ0FBQ0MsWUFBUCxFQUFWO0FBQ0FGLElBQUFBLEdBQUcsQ0FBQ0csUUFBSixDQUFhVCxlQUFlLENBQUNULEtBQWhCLEdBQXNCLENBQXRCLEdBQXdCTyxTQUFyQyxFQUFpREUsZUFBZSxDQUFDUixNQUFoQixHQUF5QixHQUExQixHQUErQk0sU0FBL0UsRUFBMEYsSUFBSVMsRUFBRSxDQUFDRyxJQUFQLENBQVksQ0FBWixFQUFlLENBQWYsQ0FBMUYsRUFBNkcsQ0FBN0c7QUFFQSxRQUFJQyxnQkFBZ0IsR0FBRyxJQUFJSixFQUFFLENBQUNLLGdCQUFQLEVBQXZCO0FBQ0FELElBQUFBLGdCQUFnQixDQUFDRSxLQUFqQixHQUF5QlAsR0FBekI7QUFDQUssSUFBQUEsZ0JBQWdCLENBQUNHLEtBQWpCLEdBQXlCUCxFQUFFLENBQUNRLGFBQTVCO0FBQ0FKLElBQUFBLGdCQUFnQixDQUFDSyxRQUFqQixDQUEwQkMsR0FBMUIsQ0FBOEIsQ0FBQ2hCLGNBQWMsQ0FBQ2lCLENBQWYsR0FBbUIvQixJQUFJLENBQUNJLEtBQUwsR0FBVyxDQUEvQixJQUFrQ08sU0FBaEUsRUFBMEUsQ0FBQ0csY0FBYyxDQUFDa0IsQ0FBZixHQUFtQmhDLElBQUksQ0FBQ0ssTUFBTCxHQUFZLENBQS9CLEdBQW1DUSxlQUFlLENBQUNSLE1BQWhCLEdBQXdCLEdBQTVELElBQWlFTSxTQUEzSTtBQUNBLFNBQUtzQixhQUFMLEdBQXFCLEtBQUtoQixjQUFMLENBQW9CaUIsbUJBQXBCLENBQXdDVixnQkFBeEMsQ0FBckI7QUFDQSxRQUFJVyxVQUFVLEdBQUcsS0FBS2xCLGNBQUwsQ0FBb0JtQixnQkFBcEIsRUFBakI7QUFDQSxTQUFLQyxVQUFMLEdBQWtCRixVQUFsQjtBQUNBLFNBQUtHLElBQUwsR0FBWSxLQUFLakQsYUFBTCxDQUFtQmtELFdBQW5CLENBQStCLENBQS9CLENBQVo7O0FBQ0EsU0FBS0QsSUFBTCxDQUFVRSxXQUFWLENBQXNCLFlBQXRCLEVBQW1DLElBQUlDLFlBQUosQ0FBaUIsQ0FBakIsQ0FBbkM7O0FBQ0EsU0FBS0gsSUFBTCxDQUFVRSxXQUFWLENBQXNCLFdBQXRCLEVBQWtDLElBQUlDLFlBQUosQ0FBaUJOLFVBQVUsR0FBRyxDQUE5QixDQUFsQzs7QUFDQU8sSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVlSLFVBQVo7QUFDQSxHQWpETztBQWtETFMsRUFBQUEsYUFsREssMkJBa0RXO0FBQUE7O0FBQ1osU0FBS0MsVUFBTDtBQUNOQyxJQUFBQSxVQUFVLENBQUMsWUFBSTtBQUNkLE1BQUEsS0FBSSxDQUFDcEMsWUFBTDs7QUFDQSxNQUFBLEtBQUksQ0FBQ3FDLFFBQUwsQ0FBYyxLQUFJLENBQUNDLGFBQW5CLEVBQWtDLElBQWxDO0FBQ0EsS0FIUyxFQUdSLEdBSFEsQ0FBVjtBQUlHLEdBeERJO0FBeURMQSxFQUFBQSxhQXpESywyQkF5RFc7QUFDbEIsUUFBSXJDLFNBQVMsR0FBRzVCLEVBQUUsQ0FBQzZCLGNBQUgsQ0FBa0JELFNBQWxDOztBQUNBLFFBQUcsS0FBS00sY0FBTCxJQUF1QixJQUExQixFQUErQjtBQUM5QixVQUFJZ0MsR0FBRyxHQUFHLEVBQVY7QUFDQSxVQUFJZCxVQUFVLEdBQUcsS0FBS2xCLGNBQUwsQ0FBb0JtQixnQkFBcEIsRUFBakI7QUFDQSxVQUFJYyxRQUFRLEdBQUcsS0FBS2pDLGNBQUwsQ0FBb0JrQyxpQkFBcEIsRUFBZjs7QUFDQSxXQUFLLElBQUlDLENBQUMsR0FBRyxDQUFiLEVBQWdCQSxDQUFDLEdBQUdqQixVQUFwQixFQUFnQ2lCLENBQUMsRUFBakMsRUFBcUM7QUFDcENILFFBQUFBLEdBQUcsQ0FBQ0ksSUFBSixDQUFTSCxRQUFRLENBQUNFLENBQUQsQ0FBUixDQUFZckIsQ0FBWixHQUFnQnBCLFNBQXpCO0FBQ0FzQyxRQUFBQSxHQUFHLENBQUNJLElBQUosQ0FBU0gsUUFBUSxDQUFDRSxDQUFELENBQVIsQ0FBWXBCLENBQVosR0FBZ0JyQixTQUF6QjtBQUNBc0MsUUFBQUEsR0FBRyxDQUFDSSxJQUFKLENBQVMsT0FBTzFDLFNBQWhCO0FBQ0FzQyxRQUFBQSxHQUFHLENBQUNJLElBQUosQ0FBUyxHQUFUO0FBQ0E7O0FBQ0QsVUFBSXJELElBQUksR0FBRyxLQUFLVCxXQUFMLENBQWlCVyxjQUFqQixFQUFYOztBQUNBLFVBQUcsS0FBS29DLElBQVIsRUFBYTtBQUNaLGFBQUtBLElBQUwsQ0FBVUUsV0FBVixDQUFzQixZQUF0QixFQUFtQyxDQUFDLEtBQUQsRUFBTyxNQUFQLEVBQWNMLFVBQWQsRUFBeUIsS0FBSzVDLFdBQUwsQ0FBaUJ5QyxDQUFqQixHQUFxQmhDLElBQUksQ0FBQ0ssTUFBTCxHQUFZLENBQWpDLEdBQXFDLEdBQTlELENBQW5DOztBQUNBLGFBQUtpQyxJQUFMLENBQVVFLFdBQVYsQ0FBc0IsV0FBdEIsRUFBa0NTLEdBQWxDO0FBQ0E7QUFDRDtBQUNFLEdBM0VJO0FBNkVMSixFQUFBQSxVQTdFSyx3QkE2RVE7QUFDVCxTQUFLUyxVQUFMLENBQWdCLEtBQUtOLGFBQXJCO0FBQ047Ozs7OztBQUtBLFFBQUcsS0FBSy9CLGNBQUwsSUFBdUIsSUFBMUIsRUFBK0I7QUFDOUIsV0FBS2dCLGFBQUwsQ0FBbUJzQixnQkFBbkIsQ0FBb0MsSUFBcEM7QUFDQSxXQUFLdEMsY0FBTCxDQUFvQnVDLG9CQUFwQixDQUF5QyxLQUFLdkIsYUFBOUM7QUFDQSxXQUFLaEIsY0FBTCxHQUFzQixJQUF0QjtBQUNBO0FBQ0U7QUF6RkksQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuXHRcdGNhbWVyYV93YXRlcjogY2MuQ2FtZXJhLFxyXG5cdFx0c3Bfd2F0ZXJfc2hvdzogY2MuU3ByaXRlLFxyXG5cdFx0c2h1aUxvbmdUb3U6Y2MuTm9kZSxcclxuICAgIH0sXHJcbiAgICBvbkxvYWQoKSB7XHJcblx0XHR0aGlzLnB5bWFuYWdlciA9IGNjLmRpcmVjdG9yLmdldFBoeXNpY3NNYW5hZ2VyKCk7XHJcblx0XHR0aGlzLnB5bWFuYWdlci5zdGFydCgpXHJcblx0XHQvKlxyXG5cdFx0dGhpcy5weW1hbmFnZXIuZGVidWdEcmF3RmxhZ3MgPSBjYy5QaHlzaWNzTWFuYWdlci5EcmF3Qml0cy5lX2FhYmJCaXQgfFxyXG5cdFx0XHRjYy5QaHlzaWNzTWFuYWdlci5EcmF3Qml0cy5lX3BhaXJCaXQgfFxyXG5cdFx0XHRjYy5QaHlzaWNzTWFuYWdlci5EcmF3Qml0cy5lX2NlbnRlck9mTWFzc0JpdCB8XHJcblx0XHRcdGNjLlBoeXNpY3NNYW5hZ2VyLkRyYXdCaXRzLmVfam9pbnRCaXQgfFxyXG5cdFx0XHRjYy5QaHlzaWNzTWFuYWdlci5EcmF3Qml0cy5lX3NoYXBlQml0IC8vfFxyXG5cdFx0XHQvL2NjLlBoeXNpY3NNYW5hZ2VyLkRyYXdCaXRzLmVfcGFydGljbGVCaXRcclxuXHRcdFx0O1xyXG5cdFx0XHQqL1xyXG5cdFx0Y29uc3QgdGV4dHVyZSA9IG5ldyBjYy5SZW5kZXJUZXh0dXJlKCk7XHJcblx0XHRsZXQgc2l6ZSA9IHRoaXMuc3Bfd2F0ZXJfc2hvdy5ub2RlLmdldENvbnRlbnRTaXplKCk7XHJcbiAgICAgICAgdGV4dHVyZS5pbml0V2l0aFNpemUoc2l6ZS53aWR0aCwgc2l6ZS5oZWlnaHQpO1xyXG5cdFx0XHJcbiAgICAgICAgY29uc3Qgc3ByaXRlRnJhbWUgPSBuZXcgY2MuU3ByaXRlRnJhbWUoKTtcclxuICAgICAgICBzcHJpdGVGcmFtZS5zZXRUZXh0dXJlKHRleHR1cmUpO1xyXG4gICAgICAgIHRoaXMuY2FtZXJhX3dhdGVyLnRhcmdldFRleHR1cmUgPSB0ZXh0dXJlO1xyXG4gICAgICAgIHRoaXMuc3Bfd2F0ZXJfc2hvdy5zcHJpdGVGcmFtZSA9IHNwcml0ZUZyYW1lO1xyXG4gICAgfSxcclxuXHRpbml0UGFydGljbGUoKXtcclxuXHRcdGxldCBQVE1fUkFUSU8gPSBjYy5QaHlzaWNzTWFuYWdlci5QVE1fUkFUSU87XHJcblx0XHR2YXIgc2h1aUxvbmdUb3VTaXplID0gdGhpcy5zaHVpTG9uZ1RvdS5nZXRDb250ZW50U2l6ZSgpO1xyXG5cdFx0dmFyIHNodWlMb25nVG91UG9zID0gdGhpcy5zaHVpTG9uZ1RvdS5nZXRQb3NpdGlvbigpO1xyXG5cdFx0dmFyIHNpemUgPSBjYy53aW5TaXplO1xyXG5cdFx0dGhpcy5wYXJ0aWNsZVN5c3RlbSA9IHRoaXMucHltYW5hZ2VyLl9wYXJ0aWNsZXM7XHJcblx0XHR2YXIgYm94ID0gbmV3IGIyLlBvbHlnb25TaGFwZSgpO1xyXG5cdFx0Ym94LlNldEFzQm94KHNodWlMb25nVG91U2l6ZS53aWR0aC8yL1BUTV9SQVRJTywgKHNodWlMb25nVG91U2l6ZS5oZWlnaHQgKiAxLjgpL1BUTV9SQVRJTywgbmV3IGIyLlZlYzIoMCwgMCksIDApO1xyXG5cclxuXHRcdHZhciBwYXJ0aWNsZUdyb3VwRGVmID0gbmV3IGIyLlBhcnRpY2xlR3JvdXBEZWYoKTtcclxuXHRcdHBhcnRpY2xlR3JvdXBEZWYuc2hhcGUgPSBib3g7XHJcblx0XHRwYXJ0aWNsZUdyb3VwRGVmLmZsYWdzID0gYjIud2F0ZXJQYXJ0aWNsZTtcclxuXHRcdHBhcnRpY2xlR3JvdXBEZWYucG9zaXRpb24uU2V0KChzaHVpTG9uZ1RvdVBvcy54ICsgc2l6ZS53aWR0aC8yKS9QVE1fUkFUSU8sKHNodWlMb25nVG91UG9zLnkgKyBzaXplLmhlaWdodC8yICsgc2h1aUxvbmdUb3VTaXplLmhlaWdodCogMS4yKS9QVE1fUkFUSU8pO1xyXG5cdFx0dGhpcy5wYXJ0aWNsZUdyb3VwID0gdGhpcy5wYXJ0aWNsZVN5c3RlbS5DcmVhdGVQYXJ0aWNsZUdyb3VwKHBhcnRpY2xlR3JvdXBEZWYpO1xyXG5cdFx0bGV0IHZlcnRzQ291bnQgPSB0aGlzLnBhcnRpY2xlU3lzdGVtLkdldFBhcnRpY2xlQ291bnQoKTtcclxuXHRcdHRoaXMudG90YWxDb3VudCA9IHZlcnRzQ291bnQ7XHJcblx0XHR0aGlzLl9tYXQgPSB0aGlzLnNwX3dhdGVyX3Nob3cuZ2V0TWF0ZXJpYWwoMCk7XHJcblx0XHR0aGlzLl9tYXQuc2V0UHJvcGVydHkoJ3Jlc29sdXRpb24nLG5ldyBGbG9hdDMyQXJyYXkoNCkpO1xyXG5cdFx0dGhpcy5fbWF0LnNldFByb3BlcnR5KCdtZXRhYmFsbHMnLG5ldyBGbG9hdDMyQXJyYXkodmVydHNDb3VudCAqIDQpKTtcclxuXHRcdGNvbnNvbGUubG9nKHZlcnRzQ291bnQpO1xyXG5cdH0sXHJcbiAgICBnZW5lcmF0ZVdhdGVyKCkge1xyXG4gICAgICAgIHRoaXMucmVzZXRXYXRlcigpO1xyXG5cdFx0c2V0VGltZW91dCgoKT0+e1xyXG5cdFx0XHR0aGlzLmluaXRQYXJ0aWNsZSgpO1xyXG5cdFx0XHR0aGlzLnNjaGVkdWxlKHRoaXMuc2NoZWR1bGVXYXRlciwgMC4wMSk7XHJcblx0XHR9LDUwMCk7XHJcbiAgICB9LFxyXG4gICAgc2NoZWR1bGVXYXRlcigpIHtcclxuXHRcdGxldCBQVE1fUkFUSU8gPSBjYy5QaHlzaWNzTWFuYWdlci5QVE1fUkFUSU87XHJcblx0XHRpZih0aGlzLnBhcnRpY2xlU3lzdGVtICE9IG51bGwpe1xyXG5cdFx0XHRsZXQgdG1wID0gW107XHJcblx0XHRcdGxldCB2ZXJ0c0NvdW50ID0gdGhpcy5wYXJ0aWNsZVN5c3RlbS5HZXRQYXJ0aWNsZUNvdW50KCk7XHJcblx0XHRcdGxldCBwb3NWZXJ0cyA9IHRoaXMucGFydGljbGVTeXN0ZW0uR2V0UG9zaXRpb25CdWZmZXIoKTtcclxuXHRcdFx0Zm9yIChsZXQgaSA9IDA7IGkgPCB2ZXJ0c0NvdW50OyBpKyspIHtcclxuXHRcdFx0XHR0bXAucHVzaChwb3NWZXJ0c1tpXS54ICogUFRNX1JBVElPKTtcclxuXHRcdFx0XHR0bXAucHVzaChwb3NWZXJ0c1tpXS55ICogUFRNX1JBVElPKTtcclxuXHRcdFx0XHR0bXAucHVzaCgwLjM1ICogUFRNX1JBVElPKTtcclxuXHRcdFx0XHR0bXAucHVzaCgwLjApO1xyXG5cdFx0XHR9XHJcblx0XHRcdGxldCBzaXplID0gdGhpcy5zaHVpTG9uZ1RvdS5nZXRDb250ZW50U2l6ZSgpO1xyXG5cdFx0XHRpZih0aGlzLl9tYXQpe1xyXG5cdFx0XHRcdHRoaXMuX21hdC5zZXRQcm9wZXJ0eSgncmVzb2x1dGlvbicsWzY0MC4wLDExMzYuMCx2ZXJ0c0NvdW50LHRoaXMuc2h1aUxvbmdUb3UueSAtIHNpemUuaGVpZ2h0LzIgKyA1NjhdKTtcclxuXHRcdFx0XHR0aGlzLl9tYXQuc2V0UHJvcGVydHkoJ21ldGFiYWxscycsdG1wKTtcclxuXHRcdFx0fVxyXG5cdFx0fVxyXG4gICAgfSxcclxuXHJcbiAgICByZXNldFdhdGVyKCkge1xyXG4gICAgICAgIHRoaXMudW5zY2hlZHVsZSh0aGlzLnNjaGVkdWxlV2F0ZXIpO1xyXG5cdFx0LypcclxuXHRcdGlmKHRoaXMuX21hdCl7XHJcblx0XHRcdHRoaXMuX21hdC5zZXRQcm9wZXJ0eSgnbWV0YWJhbGxzJyxuZXcgRmxvYXQzMkFycmF5KHRoaXMudG90YWxDb3VudCAqIDQpKTtcclxuXHRcdH1cclxuXHRcdCovXHJcblx0XHRpZih0aGlzLnBhcnRpY2xlU3lzdGVtICE9IG51bGwpe1xyXG5cdFx0XHR0aGlzLnBhcnRpY2xlR3JvdXAuRGVzdHJveVBhcnRpY2xlcyhudWxsKTtcclxuXHRcdFx0dGhpcy5wYXJ0aWNsZVN5c3RlbS5EZXN0cm95UGFydGljbGVHcm91cCh0aGlzLnBhcnRpY2xlR3JvdXApO1xyXG5cdFx0XHR0aGlzLnBhcnRpY2xlU3lzdGVtID0gbnVsbDtcclxuXHRcdH1cclxuICAgIH1cclxufSk7XHJcbiJdfQ==