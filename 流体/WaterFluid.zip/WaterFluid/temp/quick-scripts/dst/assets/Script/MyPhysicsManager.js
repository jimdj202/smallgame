
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/MyPhysicsManager.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'b77b7Rx6+FDlLve9P/euI/v', 'MyPhysicsManager');
// Script/MyPhysicsManager.js

"use strict";

cc.PhysicsManager.prototype.start = function () {
  if (CC_EDITOR) return;

  if (!this._world) {
    var world = new b2.World(new b2.Vec2(0, -9.5));
    world.SetAllowSleeping(true);
    this._world = world; //liquid 粒子

    var psd = new b2.ParticleSystemDef();
    psd.radius = 0.3;
    psd.dampingStrength = 1.5;
    psd.viscousStrength = 0;
    /*
    if(GlobalData.GameInfoConfig.gameType == 1){
    	psd.dampingStrength = 1.5;
    	psd.viscousStrength = 0;
    }else{
    	psd.dampingStrength = 2;
    	psd.viscousStrength = 0;
    	//psd.elasticStrength = 2;
    	//psd.powderStrength = 1;
    	//psd.gravityScale = 1.5;
    }
    */

    this._particles = this._world.CreateParticleSystem(psd);

    this._initCallback();
  }

  this._enabled = true;
};

b2.Draw.prototype.DrawParticles = function (positionBuffer, radius, colorBuffer, particleCount) {
  //return;
  var color = new cc.Color(255, 255, 255);

  for (var i = 0; i < particleCount; i++) {
    var vec2 = positionBuffer[i];
    this.DrawSolidCircle(vec2, radius * 1.2, 0, color);
  }
};

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxNeVBoeXNpY3NNYW5hZ2VyLmpzIl0sIm5hbWVzIjpbImNjIiwiUGh5c2ljc01hbmFnZXIiLCJwcm90b3R5cGUiLCJzdGFydCIsIkNDX0VESVRPUiIsIl93b3JsZCIsIndvcmxkIiwiYjIiLCJXb3JsZCIsIlZlYzIiLCJTZXRBbGxvd1NsZWVwaW5nIiwicHNkIiwiUGFydGljbGVTeXN0ZW1EZWYiLCJyYWRpdXMiLCJkYW1waW5nU3RyZW5ndGgiLCJ2aXNjb3VzU3RyZW5ndGgiLCJfcGFydGljbGVzIiwiQ3JlYXRlUGFydGljbGVTeXN0ZW0iLCJfaW5pdENhbGxiYWNrIiwiX2VuYWJsZWQiLCJEcmF3IiwiRHJhd1BhcnRpY2xlcyIsInBvc2l0aW9uQnVmZmVyIiwiY29sb3JCdWZmZXIiLCJwYXJ0aWNsZUNvdW50IiwiY29sb3IiLCJDb2xvciIsImkiLCJ2ZWMyIiwiRHJhd1NvbGlkQ2lyY2xlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBQSxFQUFFLENBQUNDLGNBQUgsQ0FBa0JDLFNBQWxCLENBQTRCQyxLQUE1QixHQUFvQyxZQUFVO0FBQzdDLE1BQUlDLFNBQUosRUFBZTs7QUFDZixNQUFJLENBQUMsS0FBS0MsTUFBVixFQUFrQjtBQUNqQixRQUFJQyxLQUFLLEdBQUcsSUFBSUMsRUFBRSxDQUFDQyxLQUFQLENBQWMsSUFBSUQsRUFBRSxDQUFDRSxJQUFQLENBQVksQ0FBWixFQUFlLENBQUMsR0FBaEIsQ0FBZCxDQUFaO0FBQ0FILElBQUFBLEtBQUssQ0FBQ0ksZ0JBQU4sQ0FBdUIsSUFBdkI7QUFDQSxTQUFLTCxNQUFMLEdBQWNDLEtBQWQsQ0FIaUIsQ0FJakI7O0FBQ0EsUUFBSUssR0FBRyxHQUFHLElBQUlKLEVBQUUsQ0FBQ0ssaUJBQVAsRUFBVjtBQUNBRCxJQUFBQSxHQUFHLENBQUNFLE1BQUosR0FBYSxHQUFiO0FBQ0FGLElBQUFBLEdBQUcsQ0FBQ0csZUFBSixHQUFzQixHQUF0QjtBQUNBSCxJQUFBQSxHQUFHLENBQUNJLGVBQUosR0FBc0IsQ0FBdEI7QUFDQTs7Ozs7Ozs7Ozs7OztBQVlBLFNBQUtDLFVBQUwsR0FBa0IsS0FBS1gsTUFBTCxDQUFZWSxvQkFBWixDQUFpQ04sR0FBakMsQ0FBbEI7O0FBQ0EsU0FBS08sYUFBTDtBQUNBOztBQUNELE9BQUtDLFFBQUwsR0FBZ0IsSUFBaEI7QUFDQSxDQTNCRDs7QUE0QkFaLEVBQUUsQ0FBQ2EsSUFBSCxDQUFRbEIsU0FBUixDQUFrQm1CLGFBQWxCLEdBQWtDLFVBQVVDLGNBQVYsRUFBMEJULE1BQTFCLEVBQWtDVSxXQUFsQyxFQUErQ0MsYUFBL0MsRUFBNkQ7QUFDOUY7QUFDQSxNQUFJQyxLQUFLLEdBQUcsSUFBSXpCLEVBQUUsQ0FBQzBCLEtBQVAsQ0FBYSxHQUFiLEVBQWlCLEdBQWpCLEVBQXFCLEdBQXJCLENBQVo7O0FBQ0EsT0FBSSxJQUFJQyxDQUFDLEdBQUMsQ0FBVixFQUFhQSxDQUFDLEdBQUdILGFBQWpCLEVBQWdDRyxDQUFDLEVBQWpDLEVBQXFDO0FBQ3BDLFFBQUlDLElBQUksR0FBR04sY0FBYyxDQUFDSyxDQUFELENBQXpCO0FBQ0EsU0FBS0UsZUFBTCxDQUFxQkQsSUFBckIsRUFBMEJmLE1BQU0sR0FBRyxHQUFuQyxFQUF1QyxDQUF2QyxFQUF5Q1ksS0FBekM7QUFDRztBQUNKLENBUEQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImNjLlBoeXNpY3NNYW5hZ2VyLnByb3RvdHlwZS5zdGFydCA9IGZ1bmN0aW9uKCl7XHJcblx0aWYgKENDX0VESVRPUikgcmV0dXJuO1xyXG5cdGlmICghdGhpcy5fd29ybGQpIHtcclxuXHRcdHZhciB3b3JsZCA9IG5ldyBiMi5Xb3JsZCggbmV3IGIyLlZlYzIoMCwgLTkuNSkgKTtcclxuXHRcdHdvcmxkLlNldEFsbG93U2xlZXBpbmcodHJ1ZSk7XHJcblx0XHR0aGlzLl93b3JsZCA9IHdvcmxkO1xyXG5cdFx0Ly9saXF1aWQg57KS5a2QXHJcblx0XHR2YXIgcHNkID0gbmV3IGIyLlBhcnRpY2xlU3lzdGVtRGVmKCk7XHJcblx0XHRwc2QucmFkaXVzID0gMC4zO1xyXG5cdFx0cHNkLmRhbXBpbmdTdHJlbmd0aCA9IDEuNTtcclxuXHRcdHBzZC52aXNjb3VzU3RyZW5ndGggPSAwO1xyXG5cdFx0LypcclxuXHRcdGlmKEdsb2JhbERhdGEuR2FtZUluZm9Db25maWcuZ2FtZVR5cGUgPT0gMSl7XHJcblx0XHRcdHBzZC5kYW1waW5nU3RyZW5ndGggPSAxLjU7XHJcblx0XHRcdHBzZC52aXNjb3VzU3RyZW5ndGggPSAwO1xyXG5cdFx0fWVsc2V7XHJcblx0XHRcdHBzZC5kYW1waW5nU3RyZW5ndGggPSAyO1xyXG5cdFx0XHRwc2QudmlzY291c1N0cmVuZ3RoID0gMDtcclxuXHRcdFx0Ly9wc2QuZWxhc3RpY1N0cmVuZ3RoID0gMjtcclxuXHRcdFx0Ly9wc2QucG93ZGVyU3RyZW5ndGggPSAxO1xyXG5cdFx0XHQvL3BzZC5ncmF2aXR5U2NhbGUgPSAxLjU7XHJcblx0XHR9XHJcblx0XHQqL1xyXG5cdFx0dGhpcy5fcGFydGljbGVzID0gdGhpcy5fd29ybGQuQ3JlYXRlUGFydGljbGVTeXN0ZW0ocHNkKTtcclxuXHRcdHRoaXMuX2luaXRDYWxsYmFjaygpO1xyXG5cdH1cclxuXHR0aGlzLl9lbmFibGVkID0gdHJ1ZTtcclxufTtcclxuYjIuRHJhdy5wcm90b3R5cGUuRHJhd1BhcnRpY2xlcyA9IGZ1bmN0aW9uKCBwb3NpdGlvbkJ1ZmZlciwgcmFkaXVzLCBjb2xvckJ1ZmZlciwgcGFydGljbGVDb3VudCl7XHJcblx0Ly9yZXR1cm47XHJcblx0dmFyIGNvbG9yID0gbmV3IGNjLkNvbG9yKDI1NSwyNTUsMjU1KTtcclxuXHRmb3IodmFyIGk9MDsgaSA8IHBhcnRpY2xlQ291bnQ7IGkrKykge1xyXG5cdFx0bGV0IHZlYzIgPSBwb3NpdGlvbkJ1ZmZlcltpXTtcclxuXHRcdHRoaXMuRHJhd1NvbGlkQ2lyY2xlKHZlYzIscmFkaXVzICogMS4yLDAsY29sb3IpO1xyXG4gICAgfVxyXG59OyJdfQ==