cc.Class({
  extends: cc.Component,
  properties: {

  },
  // LIFE-CYCLE CALLBACKS:
  init() {

  }
  // update (dt) {},
});